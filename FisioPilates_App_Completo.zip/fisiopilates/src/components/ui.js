// components/ui.js — design system completo

export const T = {
  sage:    '#4A7C6F',
  sageDk:  '#2E5447',
  sageLt:  '#EAF3F0',
  sageMid: '#B5D4CC',
  rose:    '#C2796A',
  roseLt:  '#FAEDEA',
  sand:    '#F7F3EE',
  white:   '#FFFFFF',
  text1:   '#1A2420',
  text2:   '#5C6E6A',
  text3:   '#9EB3AE',
  amber:   '#B8840F',
  amberLt: '#FDF3DC',
  red:     '#A33030',
  redLt:   '#FCEAEA',
  purple:  '#7C6A9E',
  purpleLt:'#F0EEFA',
};

export const FONT = "'Nunito', -apple-system, BlinkMacSystemFont, sans-serif";

export const PROFS = ['Carina Antunes', 'Dr. Rafael Lima', 'Prof. Marcos Vieira', 'Dra. Beatriz Melo'];

export function Avatar({ name = '?', size = 40, bg = T.sageLt, fg = T.sageDk }) {
  const ini = name.split(' ').slice(0, 2).map(n => n[0] || '').join('').toUpperCase();
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%', background: bg, color: fg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: size * 0.33, fontWeight: 800, flexShrink: 0, fontFamily: FONT,
      letterSpacing: '-0.02em',
    }}>{ini}</div>
  );
}

export function Pill({ label, bg, fg, dot }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      fontSize: 10.5, fontWeight: 700, padding: '3px 9px', borderRadius: 20,
      background: bg, color: fg, whiteSpace: 'nowrap', letterSpacing: '0.02em',
    }}>
      {dot && <span style={{ width: 5, height: 5, borderRadius: '50%', background: fg, opacity: 0.6 }} />}
      {label}
    </span>
  );
}

export const STATUS_MAP = {
  'Confirmado': { bg: T.sageLt,   fg: T.sageDk },
  'Pendente':   { bg: T.amberLt,  fg: T.amber  },
  'Cancelado':  { bg: T.redLt,    fg: T.red    },
  'Concluído':  { bg: T.purpleLt, fg: T.purple },
};
export const PAY_MAP = {
  'Pago':     { bg: T.sageLt,  fg: T.sageDk },
  'Pendente': { bg: T.amberLt, fg: T.amber  },
};

export function StatusPill({ status }) {
  const c = STATUS_MAP[status] || STATUS_MAP['Pendente'];
  return <Pill label={status} bg={c.bg} fg={c.fg} dot />;
}
export function PayPill({ status }) {
  const c = PAY_MAP[status] || PAY_MAP['Pendente'];
  return <Pill label={status} bg={c.bg} fg={c.fg} dot />;
}

export function Card({ children, onClick, style = {}, accent, padding = '13px 14px' }) {
  return (
    <div onClick={onClick} style={{
      background: T.white, borderRadius: 14,
      border: `1px solid ${T.sageMid}`,
      borderLeft: accent ? `3.5px solid ${accent}` : `1px solid ${T.sageMid}`,
      padding, marginBottom: 10,
      cursor: onClick ? 'pointer' : 'default',
      WebkitTapHighlightColor: 'transparent',
      ...style,
    }}>{children}</div>
  );
}

export function Field({ label, value, onChange, type = 'text', placeholder = '', textarea, rows = 3 }) {
  const base = {
    width: '100%', fontSize: 14, fontFamily: FONT,
    border: `1px solid ${T.sageMid}`, borderRadius: 10,
    padding: '9px 12px', background: '#fff', color: T.text1,
    outline: 'none', boxSizing: 'border-box',
  };
  return (
    <div style={{ marginBottom: 12 }}>
      {label && <div style={{ fontSize: 11, fontWeight: 700, color: T.text2, marginBottom: 4, letterSpacing: '0.05em', textTransform: 'uppercase' }}>{label}</div>}
      {textarea
        ? <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={rows} style={{ ...base, resize: 'vertical' }} />
        : <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={base} />}
    </div>
  );
}

export function Dropdown({ label, value, onChange, options }) {
  return (
    <div style={{ marginBottom: 12 }}>
      {label && <div style={{ fontSize: 11, fontWeight: 700, color: T.text2, marginBottom: 4, letterSpacing: '0.05em', textTransform: 'uppercase' }}>{label}</div>}
      <select value={value} onChange={e => onChange(e.target.value)} style={{
        width: '100%', fontSize: 14, fontFamily: FONT,
        border: `1px solid ${T.sageMid}`, borderRadius: 10,
        padding: '9px 12px', background: '#fff', color: T.text1, outline: 'none',
      }}>
        {options.map(o => typeof o === 'string'
          ? <option key={o} value={o}>{o}</option>
          : <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

export function Btn({ label, onClick, full, color = T.sage, outline, icon, disabled, small }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      width: full ? '100%' : 'auto',
      padding: small ? '7px 14px' : '11px 20px',
      fontSize: small ? 12 : 14, fontWeight: 700, fontFamily: FONT,
      borderRadius: 12,
      border: outline ? `1.5px solid ${color}` : 'none',
      background: outline ? 'transparent' : (disabled ? '#ccc' : color),
      color: outline ? color : '#fff',
      cursor: disabled ? 'not-allowed' : 'pointer',
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      letterSpacing: '0.01em',
    }}>
      {icon}{label}
    </button>
  );
}

export function SectionTitle({ label, action }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      margin: '18px 0 8px' }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: T.text3, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{label}</div>
      {action}
    </div>
  );
}

export function Toast({ msg, onDone }) {
  const { useEffect } = require('react');
  useEffect(() => { const t = setTimeout(onDone, 2400); return () => clearTimeout(t); }, [onDone]);
  return (
    <div style={{
      position: 'fixed', bottom: 82, left: '50%', transform: 'translateX(-50%)',
      background: T.sageDk, color: '#fff', padding: '11px 22px', borderRadius: 24,
      fontSize: 13, fontWeight: 700, zIndex: 999,
      boxShadow: '0 4px 20px rgba(0,0,0,0.22)', whiteSpace: 'nowrap', fontFamily: FONT,
    }}>{msg}</div>
  );
}

export function BottomSheet({ title, onClose, children }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(26,36,32,0.5)', zIndex: 200, display: 'flex', alignItems: 'flex-end' }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: T.sand, borderRadius: '22px 22px 0 0',
        width: '100%', maxWidth: 480, maxHeight: '92vh', overflowY: 'auto',
        padding: '0 0 36px', margin: '0 auto',
      }}>
        {/* Handle bar */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 0' }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: T.sageMid }} />
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '10px 18px 14px', borderBottom: `1px solid ${T.sageMid}` }}>
          <div style={{ fontSize: 17, fontWeight: 800, color: T.text1 }}>{title}</div>
          <button onClick={onClose} style={{
            background: T.sageLt, border: 'none', color: T.text2,
            width: 32, height: 32, borderRadius: '50%', cursor: 'pointer', fontSize: 15,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>✕</button>
        </div>
        <div style={{ padding: '16px 18px 0' }}>{children}</div>
      </div>
    </div>
  );
}

export function EmptyState({ icon, text, sub }) {
  return (
    <div style={{ textAlign: 'center', padding: '40px 20px', color: T.text3 }}>
      <div style={{ fontSize: 36, marginBottom: 10 }}>{icon}</div>
      <div style={{ fontSize: 14, fontWeight: 700, color: T.text2 }}>{text}</div>
      {sub && <div style={{ fontSize: 12, marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

export function Spinner() {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: '40px 0' }}>
      <div style={{
        width: 32, height: 32, borderRadius: '50%',
        border: `3px solid ${T.sageLt}`, borderTop: `3px solid ${T.sage}`,
        animation: 'spin 0.8s linear infinite',
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

// Color palette for avatars
export const AVATAR_PALETTE = [
  { bg: T.sageLt,   fg: T.sageDk },
  { bg: T.purpleLt, fg: T.purple },
  { bg: T.roseLt,   fg: T.rose },
  { bg: T.amberLt,  fg: T.amber },
];
