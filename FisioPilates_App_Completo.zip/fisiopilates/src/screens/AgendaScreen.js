import { useState } from 'react';
import { T, Card, Field, Dropdown, Btn, BottomSheet, SectionTitle, StatusPill, PayPill, PROFS, FONT } from '../components/ui';

function NewApptSheet({ clients, plans, onSave, onClose }) {
  const today = new Date().toISOString().slice(0, 10);
  const [form, setForm] = useState({
    clientId: String(clients[0]?.id || ''),
    planId:   String(plans[0]?.id   || ''),
    professional: PROFS[0],
    date: today, time: '09:00', duration: '60', notes: '',
  });
  const set = k => v => setForm(f => ({ ...f, [k]: v }));
  const plan   = plans.find(p => String(p.id) === form.planId);
  const client = clients.find(c => String(c.id) === form.clientId);
  const sessionVal = plan ? (plan.sessions > 1 ? Math.round(plan.price / plan.sessions) : plan.price) : 0;

  return (
    <BottomSheet title="Novo agendamento" onClose={onClose}>
      <Dropdown label="Cliente" value={form.clientId} onChange={set('clientId')}
        options={clients.map(c => ({ value: String(c.id), label: c.name }))} />
      <Dropdown label="Plano / Serviço" value={form.planId} onChange={set('planId')}
        options={plans.map(p => ({ value: String(p.id), label: `${p.name}  ·  R$${p.price}` }))} />
      <Dropdown label="Profissional" value={form.professional} onChange={set('professional')} options={PROFS} />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <Field label="Data" type="date" value={form.date} onChange={set('date')} />
        <Field label="Horário" type="time" value={form.time} onChange={set('time')} />
      </div>
      <Dropdown label="Duração" value={form.duration} onChange={set('duration')}
        options={['30','45','60','90'].map(d => ({ value: d, label: `${d} minutos` }))} />
      <Field label="Observações" value={form.notes} onChange={set('notes')} placeholder="Observações da sessão..." textarea />

      {plan && (
        <div style={{ background: T.sageLt, borderRadius: 12, padding: '12px 14px', marginBottom: 14,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 11, color: T.text2, fontWeight: 600 }}>Valor desta sessão</div>
            <div style={{ fontSize: 12, color: T.text3 }}>{plan.name}</div>
          </div>
          <div style={{ fontSize: 22, fontWeight: 800, color: T.sage }}>R${sessionVal}</div>
        </div>
      )}

      <Btn full label="Confirmar agendamento" onClick={() => {
        if (!client || !plan) return;
        onSave({
          client_id: client.id, client_name: client.name, plan_id: plan.id,
          professional: form.professional, date: form.date, time: form.time,
          duration: Number(form.duration), status: 'Pendente', pay_status: 'Pendente',
          value: sessionVal, notes: form.notes,
        });
      }} />
    </BottomSheet>
  );
}

export default function AgendaScreen({ appts, clients, plans, onSaveAppt, onUpdateAppt, onDeleteAppt, setScreen, setCtx }) {
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate]     = useState(today);
  const [showNew, setShowNew] = useState(false);

  const filtered = appts.filter(a => a.date === date).sort((a, b) => a.time.localeCompare(b.time));
  const getPlanName = id => plans.find(p => p.id === id)?.name || '—';
  const getPlanColor = id => plans.find(p => p.id === id)?.color || T.sage;

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 0' }}>
      <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end', marginBottom: 12 }}>
        <div style={{ flex: 1 }}>
          <Field label="Data" type="date" value={date} onChange={setDate} />
        </div>
        <div style={{ marginBottom: 12 }}>
          <Btn label="+ Agendar" onClick={() => setShowNew(true)} color={T.rose} />
        </div>
      </div>

      <div style={{ fontSize: 12, color: T.text2, fontWeight: 600, marginBottom: 10 }}>
        {filtered.length} agendamento(s)
      </div>

      {filtered.length === 0 && (
        <div style={{ textAlign: 'center', padding: '40px 0', color: T.text3 }}>
          <div style={{ fontSize: 32 }}>📅</div>
          <div style={{ fontSize: 13, fontWeight: 600, marginTop: 8 }}>Nenhum agendamento</div>
          <div style={{ fontSize: 12, marginTop: 4 }}>Toque em "+ Agendar" para adicionar</div>
        </div>
      )}

      {filtered.map(a => (
        <Card key={a.id} accent={getPlanColor(a.plan_id)}
          onClick={() => { setCtx({ appt: a }); setScreen('appt-detail'); }}>
          <div style={{ display: 'flex', gap: 12 }}>
            <div style={{ background: T.sageLt, borderRadius: 10, padding: '7px 10px', minWidth: 54, textAlign: 'center', flexShrink: 0 }}>
              <div style={{ fontSize: 15, fontWeight: 800, color: T.sage }}>{a.time}</div>
              <div style={{ fontSize: 9, color: T.text3, marginTop: 1 }}>{a.duration}min</div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: T.text1 }}>{a.client_name}</div>
              <div style={{ fontSize: 12, color: T.text2, marginTop: 1 }}>{getPlanName(a.plan_id)}</div>
              <div style={{ fontSize: 11, color: T.text3 }}>{a.professional}</div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4, alignItems: 'flex-end', flexShrink: 0 }}>
              <StatusPill status={a.status} />
              <PayPill status={a.pay_status} />
              <span style={{ fontSize: 12, fontWeight: 800, color: T.sageDk }}>R${a.value}</span>
            </div>
          </div>
          {a.notes ? (
            <div style={{ marginTop: 8, fontSize: 11, color: T.text3, borderTop: `1px solid ${T.sageLt}`, paddingTop: 6 }}>
              💬 {a.notes}
            </div>
          ) : null}
        </Card>
      ))}

      {showNew && (
        <NewApptSheet clients={clients} plans={plans} onClose={() => setShowNew(false)}
          onSave={async a => { await onSaveAppt(a); setShowNew(false); }} />
      )}

      <div style={{ height: 16 }} />
    </div>
  );
}
