import { useState } from 'react';
import { T, Btn, Dropdown, SectionTitle, StatusPill, PayPill, FONT } from '../components/ui';

export default function ApptDetail({ appt, plans, onBack, onUpdate, onDelete, setToast }) {
  const [status,    setStatus]  = useState(appt.status);
  const [payStatus, setPay]     = useState(appt.pay_status);
  const [delConfirm, setDelConf] = useState(false);
  const plan = plans.find(p => p.id === appt.plan_id);

  async function save() {
    await onUpdate({ ...appt, status, pay_status: payStatus });
    setToast('Agendamento atualizado ✓');
    onBack();
  }
  async function del() {
    await onDelete(appt.id);
    setToast('Agendamento removido');
    onBack();
  }

  const rows = [
    ['Data',         new Date(appt.date + 'T00:00').toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })],
    ['Horário',      appt.time],
    ['Duração',      `${appt.duration} min`],
    ['Profissional', appt.professional],
    ['Serviço',      plan?.name || '—'],
    ['Valor',        `R$${appt.value}`],
  ];

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      {/* Header */}
      <div style={{ background: `linear-gradient(135deg, ${T.sage}, ${T.sageDk})`, padding: '16px' }}>
        <button onClick={onBack} style={{
          background: 'rgba(255,255,255,0.18)', border: 'none', color: '#fff',
          padding: '6px 14px', borderRadius: 20, fontSize: 13, cursor: 'pointer',
          marginBottom: 14, fontFamily: FONT, fontWeight: 600,
        }}>← Voltar</button>
        <div style={{ fontSize: 22, fontWeight: 800, color: '#fff' }}>{appt.client_name}</div>
        <div style={{ fontSize: 13, color: T.sageMid, marginTop: 2 }}>{plan?.name || '—'}</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          <StatusPill status={appt.status} />
          <PayPill status={appt.pay_status} />
        </div>
      </div>

      <div style={{ padding: '16px' }}>
        {rows.map(([k, v]) => (
          <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: `1px solid ${T.sageLt}` }}>
            <span style={{ fontSize: 13, color: T.text2 }}>{k}</span>
            <span style={{ fontSize: 13, fontWeight: 700, color: T.text1, textAlign: 'right', maxWidth: '60%' }}>{v}</span>
          </div>
        ))}

        {appt.notes ? (
          <div style={{ marginTop: 14, background: T.sageLt, borderRadius: 10, padding: '10px 12px', fontSize: 13, color: T.text2 }}>
            💬 {appt.notes}
          </div>
        ) : null}

        <SectionTitle label="Atualizar status" />

        <Dropdown label="Status do agendamento" value={status} onChange={setStatus}
          options={['Confirmado','Pendente','Cancelado','Concluído']} />
        <Dropdown label="Status do pagamento" value={payStatus} onChange={setPay}
          options={['Pago','Pendente']} />

        <Btn full label="Salvar alterações" onClick={save} />

        <div style={{ marginTop: 12 }}>
          {!delConfirm ? (
            <Btn full label="Remover agendamento" onClick={() => setDelConf(true)} color={T.red} outline />
          ) : (
            <div style={{ background: T.redLt, borderRadius: 12, padding: '14px', textAlign: 'center' }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: T.red, marginBottom: 10 }}>Confirmar remoção?</div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
                <Btn label="Sim, remover" onClick={del} color={T.red} />
                <Btn label="Cancelar" onClick={() => setDelConf(false)} outline color={T.text2} />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
