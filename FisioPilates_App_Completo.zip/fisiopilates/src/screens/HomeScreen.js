import { T, Card, SectionTitle, StatusPill, FONT } from '../components/ui';

export default function HomeScreen({ clients, appts, plans }) {
  const today = new Date().toISOString().slice(0, 10);
  const todayAppts = appts.filter(a => a.date === today).sort((a, b) => a.time.localeCompare(b.time));
  const revenue    = appts.filter(a => a.date === today && a.pay_status === 'Pago').reduce((s, a) => s + (a.value || 0), 0);
  const pendCount  = appts.filter(a => a.pay_status === 'Pendente').length;
  const activeClts = clients.filter(c => c.active).length;
  const monthAppts = appts.filter(a => a.date && a.date.startsWith(today.slice(0, 7))).length;

  const getPlanName = planId => plans.find(p => p.id === planId)?.name || '—';

  const fmt = dateStr => {
    const d = new Date(dateStr + 'T00:00');
    return d.toLocaleDateString('pt-BR', { weekday: 'short', day: 'numeric', month: 'long' });
  };

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      {/* Hero */}
      <div style={{
        background: `linear-gradient(135deg, ${T.sage} 0%, ${T.sageDk} 100%)`,
        padding: '20px 18px 28px',
      }}>
        <div style={{ fontSize: 11, color: T.sageMid, letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 4 }}>
          {fmt(today)}
        </div>
        <div style={{ fontSize: 24, fontWeight: 800, color: '#fff', lineHeight: 1.2 }}>Bom dia! 🌿</div>
        <div style={{ fontSize: 13, color: T.sageMid, marginTop: 2 }}>FisioPilates Carina Antunes</div>

        {/* Stats row */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 20 }}>
          {[
            { num: todayAppts.length, label: 'Hoje' },
            { num: `R$${revenue}`, label: 'Recebido' },
            { num: pendCount, label: 'A cobrar' },
          ].map(s => (
            <div key={s.label} style={{
              background: 'rgba(255,255,255,0.14)', borderRadius: 12, padding: '10px 8px',
              textAlign: 'center', backdropFilter: 'blur(4px)',
            }}>
              <div style={{ fontSize: 19, fontWeight: 800, color: '#fff' }}>{s.num}</div>
              <div style={{ fontSize: 10, color: T.sageLt, marginTop: 1, fontWeight: 600 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '16px 16px 0' }}>
        {/* Secondary stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 2 }}>
          <div style={{ background: T.white, border: `1px solid ${T.sageMid}`, borderRadius: 14, padding: '14px 16px' }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: T.text3, textTransform: 'uppercase', letterSpacing: '0.07em' }}>Clientes ativos</div>
            <div style={{ fontSize: 30, fontWeight: 800, color: T.sage, marginTop: 4 }}>{activeClts}</div>
          </div>
          <div style={{ background: T.white, border: `1px solid ${T.sageMid}`, borderRadius: 14, padding: '14px 16px' }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: T.text3, textTransform: 'uppercase', letterSpacing: '0.07em' }}>Sessões no mês</div>
            <div style={{ fontSize: 30, fontWeight: 800, color: T.rose, marginTop: 4 }}>{monthAppts}</div>
          </div>
        </div>

        <SectionTitle label="Agenda de hoje" />

        {todayAppts.length === 0 && (
          <div style={{ textAlign: 'center', padding: '28px 0', color: T.text3 }}>
            <div style={{ fontSize: 32 }}>🌿</div>
            <div style={{ fontSize: 13, fontWeight: 600, marginTop: 8 }}>Nenhum agendamento hoje</div>
          </div>
        )}

        {todayAppts.map(a => (
          <div key={a.id} style={{
            display: 'flex', alignItems: 'center', gap: 12,
            background: T.white, border: `1px solid ${T.sageMid}`,
            borderRadius: 14, padding: '12px 14px', marginBottom: 8,
          }}>
            <div style={{
              background: T.sageLt, borderRadius: 10, padding: '8px 10px',
              minWidth: 52, textAlign: 'center', flexShrink: 0,
            }}>
              <div style={{ fontSize: 15, fontWeight: 800, color: T.sage, fontFamily: FONT }}>{a.time}</div>
              <div style={{ fontSize: 9, color: T.text3, marginTop: 1 }}>{a.duration}min</div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: T.text1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {a.client_name}
              </div>
              <div style={{ fontSize: 11, color: T.text2, marginTop: 1 }}>{getPlanName(a.plan_id)}</div>
              <div style={{ fontSize: 11, color: T.text3 }}>{a.professional}</div>
            </div>
            <StatusPill status={a.status} />
          </div>
        ))}

        <div style={{ height: 16 }} />
      </div>
    </div>
  );
}
