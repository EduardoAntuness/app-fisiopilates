import { useState } from 'react';
import { T, Card, Field, Btn, BottomSheet, SectionTitle, Avatar, EmptyState, PROFS, FONT } from '../components/ui';

const COLOR_OPTIONS = [
  '#4A7C6F','#2E5447','#C2796A','#B8840F',
  '#7C6A9E','#6A7C9E','#A06030','#307060',
  '#5A8A4A','#8A4A5A','#4A5A8A','#8A8A4A',
];

function PlanSheet({ plan, onSave, onClose }) {
  const isNew = !plan.id;
  const [form, setForm] = useState({
    name: plan.name || '', price: String(plan.price || ''),
    sessions: String(plan.sessions || '1'), color: plan.color || T.sage,
  });
  const set = k => v => setForm(f => ({ ...f, [k]: v }));
  const sessVal = form.price && form.sessions && Number(form.sessions) > 1
    ? Math.round(Number(form.price) / Number(form.sessions)) : null;

  function save() {
    if (!form.name.trim()) { alert('Nome do plano é obrigatório'); return; }
    if (!form.price || Number(form.price) <= 0) { alert('Informe o valor'); return; }
    onSave({ ...plan, name: form.name, price: Number(form.price), sessions: Number(form.sessions), color: form.color });
  }

  return (
    <BottomSheet title={isNew ? 'Novo plano' : 'Editar plano'} onClose={onClose}>
      <Field label="Nome do plano / serviço" value={form.name} onChange={set('name')} placeholder="Ex: Pilates Mensal 8x" />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <Field label="Valor total (R$)" value={form.price} onChange={set('price')} type="number" placeholder="0" />
        <Field label="Qtd. sessões" value={form.sessions} onChange={set('sessions')} type="number" placeholder="1" />
      </div>

      {sessVal && (
        <div style={{ background: T.sageLt, borderRadius: 10, padding: '10px 12px', marginBottom: 12, display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 12, color: T.text2 }}>Valor por sessão</span>
          <span style={{ fontSize: 16, fontWeight: 800, color: T.sage }}>R${sessVal}</span>
        </div>
      )}

      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: T.text2, marginBottom: 8, letterSpacing: '0.05em', textTransform: 'uppercase' }}>Cor de identificação</div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {COLOR_OPTIONS.map(c => (
            <button key={c} onClick={() => set('color')(c)} style={{
              width: 30, height: 30, borderRadius: '50%', background: c, border: 'none', cursor: 'pointer',
              outline: form.color === c ? `3px solid ${c}` : 'none',
              outlineOffset: form.color === c ? '2px' : '0',
              transform: form.color === c ? 'scale(1.15)' : 'scale(1)',
              transition: 'transform 0.15s',
            }} />
          ))}
        </div>
      </div>

      <Btn full label={isNew ? 'Criar plano' : 'Salvar alterações'} onClick={save} />
    </BottomSheet>
  );
}

export default function ConfigScreen({ plans, setPlans, onSavePlan, onDeletePlan, setToast }) {
  const [editing, setEditing] = useState(null);
  const [showNew, setShowNew] = useState(false);
  const [delId, setDelId]     = useState(null);

  async function save(plan) {
    await onSavePlan(plan);
    setEditing(null); setShowNew(false);
    setToast(plan.id ? 'Plano atualizado ✓' : 'Plano criado ✓');
  }

  async function del(id) {
    await onDeletePlan(id);
    setDelId(null);
    setToast('Plano removido');
  }

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 0' }}>
      {/* Plans */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <div style={{ fontSize: 16, fontWeight: 800, color: T.text1 }}>Planos & Serviços</div>
        <Btn label="+ Novo plano" onClick={() => setShowNew(true)} color={T.rose} small />
      </div>

      {plans.length === 0 && <EmptyState icon="📋" text="Nenhum plano cadastrado" sub="Adicione o primeiro plano" />}

      {plans.map(p => (
        <Card key={p.id} accent={p.color}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 12, height: 12, borderRadius: '50%', background: p.color, flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: T.text1 }}>{p.name}</div>
              <div style={{ fontSize: 12, color: T.text2 }}>
                R${p.price}
                {p.sessions > 1 && <span style={{ color: T.text3 }}> · {p.sessions} sessões · R${Math.round(p.price/p.sessions)}/sessão</span>}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <button onClick={() => setEditing(p)} style={{
                background: T.sageLt, border: 'none', color: T.sageDk,
                borderRadius: 8, padding: '5px 10px', fontSize: 12, cursor: 'pointer', fontWeight: 700, fontFamily: FONT }}>
                Editar
              </button>
              <button onClick={() => setDelId(p.id)} style={{
                background: T.redLt, border: 'none', color: T.red,
                borderRadius: 8, padding: '5px 10px', fontSize: 12, cursor: 'pointer', fontWeight: 700, fontFamily: FONT }}>
                ✕
              </button>
            </div>
          </div>
        </Card>
      ))}

      {/* Confirm delete */}
      {delId && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(26,36,32,0.5)', zIndex: 300, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: T.white, borderRadius: 16, padding: '24px', maxWidth: 320, width: '100%' }}>
            <div style={{ fontSize: 16, fontWeight: 800, color: T.text1, marginBottom: 8 }}>Remover plano?</div>
            <div style={{ fontSize: 13, color: T.text2, marginBottom: 20 }}>Esta ação não pode ser desfeita.</div>
            <div style={{ display: 'flex', gap: 8 }}>
              <Btn full label="Sim, remover" onClick={() => del(delId)} color={T.red} />
              <Btn full label="Cancelar" onClick={() => setDelId(null)} outline color={T.text3} />
            </div>
          </div>
        </div>
      )}

      {/* Professionals */}
      <SectionTitle label="Profissionais" />
      {PROFS.map((p, i) => (
        <div key={p} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: `1px solid ${T.sageLt}` }}>
          <Avatar name={p} size={36} />
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: T.text1 }}>{p}</div>
            <div style={{ fontSize: 11, color: T.text3 }}>{i === 0 ? 'Proprietária' : 'Colaborador(a)'}</div>
          </div>
        </div>
      ))}

      {/* About */}
      <SectionTitle label="Sobre o app" />
      <Card>
        <div style={{ textAlign: 'center', padding: '8px 0' }}>
          <div style={{ fontSize: 28, marginBottom: 8 }}>🌿</div>
          <div style={{ fontSize: 16, fontWeight: 800, color: T.sage }}>FisioPilates</div>
          <div style={{ fontSize: 13, fontWeight: 700, color: T.text1 }}>Carina Antunes</div>
          <div style={{ fontSize: 12, color: T.text2, marginTop: 4 }}>Fisioterapia · Pilates · Massagem</div>
          <div style={{ fontSize: 11, color: T.text3, marginTop: 10 }}>Versão 1.0.0</div>
        </div>
      </Card>

      {editing && <PlanSheet plan={editing} onSave={save} onClose={() => setEditing(null)} />}
      {showNew && <PlanSheet plan={{ name:'', price:'', sessions:'1', color: T.sage }} onSave={save} onClose={() => setShowNew(false)} />}

      <div style={{ height: 16 }} />
    </div>
  );
}
