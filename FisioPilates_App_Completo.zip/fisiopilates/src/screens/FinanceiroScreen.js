import { useState } from 'react';
import { T, Card, Field, SectionTitle, PayPill, EmptyState, FONT } from '../components/ui';

export default function FinanceiroScreen({ appts, plans }) {
  const thisMonth = new Date().toISOString().slice(0, 7);
  const [month, setMonth] = useState(thisMonth);

  const filtered  = appts.filter(a => a.date && a.date.startsWith(month));
  const recebido  = filtered.filter(a => a.pay_status === 'Pago').reduce((s, a) => s + (a.value || 0), 0);
  const pendente  = filtered.filter(a => a.pay_status === 'Pendente').reduce((s, a) => s + (a.value || 0), 0);
  const total     = recebido + pendente;

  const byPlan = plans.map(p => ({
    ...p,
    count: filtered.filter(a => a.plan_id === p.id).length,
    pago:  filtered.filter(a => a.plan_id === p.id && a.pay_status === 'Pago').reduce((s, a) => s + (a.value||0), 0),
  })).filter(p => p.count > 0);

  const pct = total > 0 ? Math.round((recebido / total) * 100) : 0;

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 0' }}>
      <Field label="Mês" type="month" value={month} onChange={setMonth} />

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
        <div style={{ background: T.sageLt, borderRadius: 14, padding: '16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: T.sageDk, textTransform: 'uppercase', letterSpacing: '0.07em' }}>Recebido</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: T.sage, marginTop: 4 }}>R${recebido}</div>
        </div>
        <div style={{ background: T.amberLt, borderRadius: 14, padding: '16px' }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: T.amber, textTransform: 'uppercase', letterSpacing: '0.07em' }}>A receber</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: T.amber, marginTop: 4 }}>R${pendente}</div>
        </div>
      </div>

      {/* Progress bar */}
      {total > 0 && (
        <div style={{ background: T.white, border: `1px solid ${T.sageMid}`, borderRadius: 14, padding: '14px 16px', marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 12, fontWeight: 700, color: T.text2 }}>Taxa de recebimento</span>
            <span style={{ fontSize: 13, fontWeight: 800, color: T.sage }}>{pct}%</span>
          </div>
          <div style={{ height: 8, background: T.sageLt, borderRadius: 4, overflow: 'hidden' }}>
            <div style={{ height: '100%', width: `${pct}%`, background: T.sage, borderRadius: 4, transition: 'width 0.4s' }} />
          </div>
          <div style={{ fontSize: 11, color: T.text3, marginTop: 6 }}>Total: R${total} · {filtered.length} sessões</div>
        </div>
      )}

      <SectionTitle label="Por serviço" />
      {byPlan.length === 0 && <EmptyState icon="💰" text="Nenhum dado neste período" sub="Selecione outro mês" />}
      {byPlan.map(p => (
        <Card key={p.id} accent={p.color}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: p.color, flexShrink: 0 }} />
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: T.text1 }}>{p.name}</div>
                <div style={{ fontSize: 11, color: T.text2 }}>{p.count} sessão(ões)</div>
              </div>
            </div>
            <div style={{ fontSize: 16, fontWeight: 800, color: T.sageDk }}>R${p.pago}</div>
          </div>
        </Card>
      ))}

      <SectionTitle label="Lançamentos" />
      {filtered.length === 0 && <EmptyState icon="📋" text="Nenhum lançamento" sub="" />}
      {filtered.sort((a,b) => b.date.localeCompare(a.date)).map(a => (
        <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '10px 0', borderBottom: `1px solid ${T.sageLt}` }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: T.text1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.client_name}</div>
            <div style={{ fontSize: 11, color: T.text3 }}>
              {plans.find(p => p.id === a.plan_id)?.name || '—'} · {new Date(a.date+'T00:00').toLocaleDateString('pt-BR')}
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, alignItems: 'flex-end', flexShrink: 0, marginLeft: 8 }}>
            <PayPill status={a.pay_status} />
            <span style={{ fontSize: 12, fontWeight: 700, color: T.text1 }}>R${a.value}</span>
          </div>
        </div>
      ))}

      <div style={{ height: 16 }} />
    </div>
  );
}
