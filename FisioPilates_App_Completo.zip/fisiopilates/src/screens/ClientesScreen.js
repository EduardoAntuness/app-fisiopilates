import { useState } from 'react';
import { T, Avatar, Card, Field, Dropdown, Btn, BottomSheet, SectionTitle, StatusPill, PayPill, PayPill as _, EmptyState, AVATAR_PALETTE, PROFS, FONT } from '../components/ui';

// ── New/Edit Client Sheet ─────────────────────────────────────
export function ClientSheet({ plans, existing, onSave, onClose }) {
  const [form, setForm] = useState(existing ? {
    name: existing.name, phone: existing.phone, email: existing.email || '',
    dob: existing.dob || '', planId: String(existing.plan_id || plans[0]?.id), notes: existing.notes || '',
  } : { name: '', phone: '', email: '', dob: '', planId: String(plans[0]?.id || ''), notes: '' });

  const set = k => v => setForm(f => ({ ...f, [k]: v }));

  function save() {
    if (!form.name.trim()) { alert('Nome é obrigatório'); return; }
    if (!form.phone.trim()) { alert('Telefone é obrigatório'); return; }
    const data = {
      ...(existing || {}),
      name: form.name, phone: form.phone, email: form.email,
      dob: form.dob, plan_id: form.planId,
      notes: form.notes,
      since: existing?.since || new Date().toISOString().slice(0, 10),
      active: existing?.active !== undefined ? existing.active : true,
    };
    onSave(data);
  }

  return (
    <BottomSheet title={existing ? 'Editar cliente' : 'Novo cliente'} onClose={onClose}>
      <Field label="Nome completo *" value={form.name} onChange={set('name')} placeholder="Ex: Maria Oliveira" />
      <Field label="Telefone / WhatsApp *" value={form.phone} onChange={set('phone')} placeholder="(11) 99999-9999" />
      <Field label="E-mail" value={form.email} onChange={set('email')} type="email" placeholder="cliente@email.com" />
      <Field label="Data de nascimento" value={form.dob} onChange={set('dob')} type="date" />
      <Dropdown label="Plano principal" value={form.planId} onChange={set('planId')}
        options={plans.map(p => ({ value: String(p.id), label: `${p.name}  ·  R$${p.price}` }))} />
      <Field label="Histórico / Observações" value={form.notes} onChange={set('notes')}
        placeholder="Lesões, histórico médico, preferências de atendimento..." textarea rows={3} />
      <Btn full label={existing ? 'Salvar alterações' : 'Cadastrar cliente'} onClick={save} />
    </BottomSheet>
  );
}

// ── Clients List ──────────────────────────────────────────────
export default function ClientesScreen({ clients, plans, setScreen, setCtx, showNewClient, setShowNewClient, onSaveClient, setToast }) {
  const [q, setQ]           = useState('');
  const [filter, setFilter] = useState('todos');

  const list = clients.filter(c => {
    const match = c.name.toLowerCase().includes(q.toLowerCase()) || (c.phone || '').includes(q);
    if (filter === 'ativos')   return match && c.active;
    if (filter === 'inativos') return match && !c.active;
    return match;
  });

  const getPlanName = id => plans.find(p => p.id === id)?.name || '—';

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: '16px 16px 0' }}>
      {/* Search + Add */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="🔍  Buscar cliente..."
          style={{ flex: 1, fontSize: 14, fontFamily: FONT, border: `1px solid ${T.sageMid}`,
            borderRadius: 10, padding: '9px 12px', background: '#fff', color: T.text1, outline: 'none' }} />
        <Btn label="+ Novo" onClick={() => setShowNewClient(true)} color={T.rose} />
      </div>

      {/* Filter chips */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
        {['todos','ativos','inativos'].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{
            padding: '5px 14px', fontSize: 12, borderRadius: 20,
            border: `1.5px solid ${filter === f ? T.sage : T.sageMid}`,
            background: filter === f ? T.sage : T.white,
            color: filter === f ? '#fff' : T.text2,
            cursor: 'pointer', fontWeight: 700, fontFamily: FONT,
            textTransform: 'capitalize',
          }}>{f}</button>
        ))}
      </div>

      <div style={{ fontSize: 12, color: T.text2, fontWeight: 600, marginBottom: 8 }}>{list.length} cliente(s)</div>

      {list.length === 0 && <EmptyState icon="👥" text="Nenhum cliente encontrado" sub="Ajuste a busca ou cadastre um novo" />}

      {list.map((c, i) => {
        const col = AVATAR_PALETTE[i % AVATAR_PALETTE.length];
        return (
          <Card key={c.id} onClick={() => { setCtx({ client: c }); setScreen('client-detail'); }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Avatar name={c.name} size={48} bg={col.bg} fg={col.fg} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: T.text1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.name}</div>
                <div style={{ fontSize: 12, color: T.text2, marginTop: 1 }}>{getPlanName(c.plan_id)}</div>
                <div style={{ fontSize: 11, color: T.text3 }}>{c.phone}</div>
              </div>
              <div style={{
                padding: '3px 10px', borderRadius: 20, fontSize: 10.5, fontWeight: 700,
                background: c.active ? T.sageLt : '#F3F4F6',
                color: c.active ? T.sageDk : '#9ca3af',
              }}>{c.active ? 'Ativa' : 'Inativa'}</div>
            </div>
          </Card>
        );
      })}

      {showNewClient && (
        <ClientSheet plans={plans} onClose={() => setShowNewClient(false)}
          onSave={async data => {
            await onSaveClient(data);
            setShowNewClient(false);
            setToast('Cliente cadastrado ✓');
          }} />
      )}
      <div style={{ height: 16 }} />
    </div>
  );
}

// ── Client Detail ─────────────────────────────────────────────
export function ClientDetail({ client, clients, appts, evolutions, plans, onBack, onSaveClient, onSaveEvolution, setToast }) {
  const [tab, setTab]       = useState('info');
  const [evoForm, setEvo]   = useState(false);
  const [evoText, setTxt]   = useState('');
  const [evoNext, setNext]  = useState('');
  const [editing, setEdit]  = useState(false);

  const plan       = plans.find(p => p.id === client.plan_id);
  const clientApts = appts.filter(a => a.client_id === client.id).sort((a, b) => b.date.localeCompare(a.date));
  const clientEvos = evolutions.filter(e => e.client_id === client.id).sort((a, b) => b.date.localeCompare(a.date));
  const getPlanName = id => plans.find(p => p.id === id)?.name || '—';

  async function addEvo() {
    if (!evoText.trim()) return;
    await onSaveEvolution({ client_id: client.id, date: new Date().toISOString().slice(0,10), professional: PROFS[0], text: evoText, next_steps: evoNext });
    setTxt(''); setNext(''); setEvo(false);
    setToast('Evolução registrada ✓');
  }

  const infoRows = [
    ['E-mail', client.email || '—'],
    ['Nascimento', client.dob ? new Date(client.dob+'T00:00').toLocaleDateString('pt-BR') : '—'],
    ['Cliente desde', new Date((client.since||'2024-01-01')+'T00:00').toLocaleDateString('pt-BR')],
    ['Plano', plan?.name || '—'],
    ['Valor do plano', plan ? `R$${plan.price} · ${plan.sessions} sessão(ões)` : '—'],
    ['Status', client.active ? '🟢 Ativa' : '⚫ Inativa'],
  ];

  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      {/* Header */}
      <div style={{ background: `linear-gradient(135deg, ${T.sage}, ${T.sageDk})`, padding: '16px 16px 0' }}>
        <button onClick={onBack} style={{ background: 'rgba(255,255,255,0.18)', border: 'none', color: '#fff',
          padding: '6px 14px', borderRadius: 20, fontSize: 13, cursor: 'pointer', marginBottom: 14,
          fontFamily: FONT, fontWeight: 600 }}>← Voltar</button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, paddingBottom: 0 }}>
          <Avatar name={client.name} size={56} bg="rgba(255,255,255,0.22)" fg="#fff" />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 20, fontWeight: 800, color: '#fff' }}>{client.name}</div>
            <div style={{ fontSize: 12, color: T.sageMid }}>{plan?.name || '—'}</div>
            <div style={{ fontSize: 12, color: T.sageMid }}>{client.phone}</div>
          </div>
          <button onClick={() => setEdit(true)} style={{ background: 'rgba(255,255,255,0.18)', border: 'none',
            color: '#fff', padding: '6px 12px', borderRadius: 10, cursor: 'pointer', fontSize: 12, fontFamily: FONT }}>Editar</button>
        </div>
        {/* Tabs */}
        <div style={{ display: 'flex', marginTop: 14 }}>
          {['info','agenda','evolução'].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{
              flex: 1, padding: '10px 0', background: 'none', border: 'none',
              borderBottom: tab === t ? '2.5px solid #fff' : '2.5px solid transparent',
              color: tab === t ? '#fff' : T.sageMid, fontSize: 13, fontWeight: tab === t ? 800 : 500,
              cursor: 'pointer', textTransform: 'capitalize', fontFamily: FONT,
            }}>{t}</button>
          ))}
        </div>
      </div>

      <div style={{ padding: '16px' }}>
        {/* INFO TAB */}
        {tab === 'info' && (
          <>
            {infoRows.map(([k, v]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: `1px solid ${T.sageLt}` }}>
                <span style={{ fontSize: 13, color: T.text2 }}>{k}</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: T.text1, textAlign: 'right', maxWidth: '60%' }}>{v}</span>
              </div>
            ))}
            <SectionTitle label="Observações" />
            <div style={{ fontSize: 13, lineHeight: 1.7, color: T.text1, background: T.sageLt, borderRadius: 12, padding: '12px 14px' }}>
              {client.notes || 'Nenhuma observação registrada.'}
            </div>
          </>
        )}

        {/* AGENDA TAB */}
        {tab === 'agenda' && (
          <>
            <div style={{ fontSize: 12, color: T.text2, fontWeight: 600, marginBottom: 10 }}>
              {clientApts.length} agendamento(s)
            </div>
            {clientApts.length === 0 && <EmptyState icon="📅" text="Nenhum agendamento" sub="Agende pela aba Agenda" />}
            {clientApts.map(a => (
              <Card key={a.id} accent={plans.find(p=>p.id===a.plan_id)?.color || T.sage}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700 }}>{new Date(a.date+'T00:00').toLocaleDateString('pt-BR')} às {a.time}</div>
                    <div style={{ fontSize: 12, color: T.text2 }}>{getPlanName(a.plan_id)}</div>
                    <div style={{ fontSize: 11, color: T.text3 }}>{a.professional}</div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 4, alignItems: 'flex-end' }}>
                    <StatusPill status={a.status} />
                    <PayPill status={a.pay_status} />
                    <span style={{ fontSize: 12, fontWeight: 700 }}>R${a.value}</span>
                  </div>
                </div>
              </Card>
            ))}
          </>
        )}

        {/* EVOLUÇÃO TAB */}
        {tab === 'evolução' && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <span style={{ fontSize: 12, color: T.text2, fontWeight: 600 }}>{clientEvos.length} registro(s)</span>
              <Btn label="+ Registrar" onClick={() => setEvo(true)} small />
            </div>

            {evoForm && (
              <div style={{ background: T.sageLt, borderRadius: 14, padding: '14px', marginBottom: 12, border: `1px solid ${T.sageMid}` }}>
                <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 10, color: T.text1 }}>Nova evolução</div>
                <Field label="Descrição da sessão" value={evoText} onChange={setTxt}
                  placeholder="O que foi realizado, resposta da paciente..." textarea />
                <Field label="Próximos passos" value={evoNext} onChange={setNext}
                  placeholder="Orientações para a próxima sessão..." />
                <div style={{ display: 'flex', gap: 8 }}>
                  <Btn label="Salvar" onClick={addEvo} small />
                  <Btn label="Cancelar" onClick={() => setEvo(false)} small outline color={T.text3} />
                </div>
              </div>
            )}

            {clientEvos.length === 0 && !evoForm && <EmptyState icon="📋" text="Nenhuma evolução registrada" sub="Registre o progresso da paciente" />}

            {clientEvos.map(e => (
              <Card key={e.id} accent={T.sage}>
                <div style={{ fontSize: 11, color: T.text3, marginBottom: 6 }}>
                  {new Date(e.date+'T00:00').toLocaleDateString('pt-BR')} · {e.professional}
                </div>
                <div style={{ fontSize: 13, lineHeight: 1.65, color: T.text1 }}>{e.text}</div>
                {e.next_steps && (
                  <div style={{ marginTop: 8, fontSize: 12, color: T.sageDk, background: T.sageLt, borderRadius: 8, padding: '6px 10px' }}>
                    → {e.next_steps}
                  </div>
                )}
              </Card>
            ))}
          </>
        )}
      </div>

      {editing && (
        <ClientSheet plans={plans} existing={client} onClose={() => setEdit(false)}
          onSave={async data => {
            await onSaveClient(data);
            setEdit(false);
            setToast('Cliente atualizado ✓');
          }} />
      )}
    </div>
  );
}
