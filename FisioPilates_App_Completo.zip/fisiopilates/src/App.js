import { useState, useEffect, useCallback } from 'react';
import { db } from './lib/db';
import { T, Toast, FONT } from './components/ui';
import HomeScreen      from './screens/HomeScreen';
import AgendaScreen    from './screens/AgendaScreen';
import ApptDetail      from './screens/ApptDetail';
import ClientesScreen, { ClientDetail, ClientSheet } from './screens/ClientesScreen';
import FinanceiroScreen from './screens/FinanceiroScreen';
import ConfigScreen    from './screens/ConfigScreen';

const NAV = [
  { id: 'home',       emoji: '🏠', label: 'Início'     },
  { id: 'agenda',     emoji: '📅', label: 'Agenda'     },
  { id: 'clientes',   emoji: '👥', label: 'Clientes'   },
  { id: 'financeiro', emoji: '💰', label: 'Financeiro' },
  { id: 'config',     emoji: '⚙️', label: 'Configurar' },
];

export default function App() {
  const [tab,    setTab]    = useState('home');
  const [screen, setScreen] = useState('home');
  const [ctx,    setCtx]    = useState({});
  const [toast,  setToast]  = useState(null);

  const [plans,      setPlans]      = useState([]);
  const [clients,    setClients]    = useState([]);
  const [appts,      setAppts]      = useState([]);
  const [evolutions, setEvolutions] = useState([]);
  const [loading,    setLoading]    = useState(true);

  const [showNewClient, setShowNewClient] = useState(false);

  // Load all data on mount
  useEffect(() => {
    async function load() {
      await db.init();
      const [p, c, a, e] = await Promise.all([
        db.getPlans(), db.getClients(), db.getAppointments(), db.getEvolutions(),
      ]);
      setPlans(p); setClients(c); setAppts(a); setEvolutions(e);
      setLoading(false);
    }
    load();
  }, []);

  function navTo(t) { setTab(t); setScreen(t); setCtx({}); }

  // ── Data mutations ──────────────────────────────────────────
  const savePlan = useCallback(async plan => {
    const saved = await db.savePlan(plan);
    setPlans(prev => prev.find(p => p.id === (saved.id || plan.id))
      ? prev.map(p => p.id === (saved.id || plan.id) ? (saved || plan) : p)
      : [...prev, saved || plan]);
  }, []);

  const deletePlan = useCallback(async id => {
    await db.deletePlan(id);
    setPlans(prev => prev.filter(p => p.id !== id));
  }, []);

  const saveClient = useCallback(async client => {
    const saved = await db.saveClient(client);
    const c = saved || client;
    setClients(prev => prev.find(x => x.id === c.id)
      ? prev.map(x => x.id === c.id ? c : x)
      : [...prev, c]);
    // Update ctx if we're viewing this client
    if (ctx.client && ctx.client.id === c.id) setCtx(prev => ({ ...prev, client: c }));
    return c;
  }, [ctx.client]);

  const saveAppt = useCallback(async appt => {
    const saved = await db.saveAppointment(appt);
    const a = saved || appt;
    setAppts(prev => prev.find(x => x.id === a.id)
      ? prev.map(x => x.id === a.id ? a : x)
      : [...prev, a]);
    return a;
  }, []);

  const deleteAppt = useCallback(async id => {
    await db.deleteAppointment(id);
    setAppts(prev => prev.filter(a => a.id !== id));
  }, []);

  const saveEvolution = useCallback(async evo => {
    const saved = await db.saveEvolution(evo);
    setEvolutions(prev => [...prev, saved || evo]);
  }, []);

  const isDetail = ['client-detail','appt-detail'].includes(screen);

  if (loading) {
    return (
      <div style={{ height: '100dvh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: T.sand, fontFamily: FONT }}>
        <div style={{ fontSize: 40, marginBottom: 16 }}>🌿</div>
        <div style={{ fontSize: 16, fontWeight: 800, color: T.sage }}>FisioPilates</div>
        <div style={{ fontSize: 12, color: T.text2, marginTop: 4 }}>Carina Antunes</div>
        <div style={{ marginTop: 24, width: 32, height: 32, borderRadius: '50%',
          border: `3px solid ${T.sageLt}`, borderTop: `3px solid ${T.sage}`,
          animation: 'spin 0.8s linear infinite' }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return (
    <div style={{ fontFamily: FONT, maxWidth: 480, margin: '0 auto', height: '100dvh',
      display: 'flex', flexDirection: 'column', background: T.sand, overflow: 'hidden' }}>

      {/* ── Top bar ── */}
      {!isDetail && (
        <div style={{ background: T.sageDk, padding: '12px 16px 10px', flexShrink: 0,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 800, color: '#fff', letterSpacing: '-0.01em', lineHeight: 1.1 }}>🌿 FisioPilates</div>
            <div style={{ fontSize: 10, color: T.sageMid, letterSpacing: '0.04em' }}>CARINA ANTUNES</div>
          </div>
          <button onClick={() => setShowNewClient(true)} style={{
            background: T.rose, border: 'none', color: '#fff',
            padding: '7px 16px', borderRadius: 20, fontSize: 12,
            fontWeight: 800, cursor: 'pointer', fontFamily: FONT,
          }}>+ Cliente</button>
        </div>
      )}

      {/* ── Screen content ── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {screen === 'home' && (
          <HomeScreen clients={clients} appts={appts} plans={plans} />
        )}

        {screen === 'agenda' && (
          <AgendaScreen appts={appts} clients={clients} plans={plans}
            onSaveAppt={saveAppt} onUpdateAppt={saveAppt} onDeleteAppt={deleteAppt}
            setScreen={setScreen} setCtx={setCtx} />
        )}

        {screen === 'clientes' && (
          <ClientesScreen clients={clients} plans={plans}
            setScreen={setScreen} setCtx={setCtx}
            showNewClient={showNewClient} setShowNewClient={setShowNewClient}
            onSaveClient={saveClient} setToast={setToast} />
        )}

        {screen === 'financeiro' && (
          <FinanceiroScreen appts={appts} plans={plans} />
        )}

        {screen === 'config' && (
          <ConfigScreen plans={plans}
            onSavePlan={savePlan} onDeletePlan={deletePlan} setToast={setToast} />
        )}

        {screen === 'client-detail' && ctx.client && (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: T.sand }}>
            <ClientDetail
              client={ctx.client} clients={clients}
              appts={appts} evolutions={evolutions} plans={plans}
              onBack={() => setScreen('clientes')}
              onSaveClient={saveClient} onSaveEvolution={saveEvolution}
              setToast={setToast} />
          </div>
        )}

        {screen === 'appt-detail' && ctx.appt && (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: T.sand }}>
            <ApptDetail
              appt={ctx.appt} plans={plans}
              onBack={() => setScreen('agenda')}
              onUpdate={saveAppt} onDelete={deleteAppt}
              setToast={setToast} />
          </div>
        )}
      </div>

      {/* ── Bottom navigation ── */}
      {!isDetail && (
        <div style={{ background: '#fff', borderTop: `1px solid ${T.sageMid}`,
          display: 'flex', paddingBottom: 'env(safe-area-inset-bottom, 4px)', flexShrink: 0 }}>
          {NAV.map(n => (
            <button key={n.id} onClick={() => navTo(n.id)} style={{
              flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
              background: 'none', border: 'none', padding: '9px 0 5px',
              cursor: 'pointer', fontFamily: FONT, WebkitTapHighlightColor: 'transparent',
            }}>
              <span style={{ fontSize: 20 }}>{n.emoji}</span>
              <span style={{ fontSize: 9, fontWeight: tab === n.id ? 800 : 500,
                color: tab === n.id ? T.sage : T.text3 }}>{n.label}</span>
              {tab === n.id && (
                <div style={{ width: 18, height: 2.5, borderRadius: 2, background: T.sage, marginTop: 1 }} />
              )}
            </button>
          ))}
        </div>
      )}

      {/* ── Global overlay: new client ── */}
      {showNewClient && screen !== 'clientes' && (
        <ClientSheet plans={plans} onClose={() => setShowNewClient(false)}
          onSave={async data => {
            await saveClient(data);
            setShowNewClient(false);
            setToast('Cliente cadastrado ✓');
          }} />
      )}

      {/* ── Toast ── */}
      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
    </div>
  );
}
