# 🌿 FisioPilates Carina Antunes — Guia Completo de Publicação

## O que está incluído neste projeto

```
fisiopilates/
├── public/
│   ├── index.html       ← Página principal com PWA configurado
│   ├── manifest.json    ← Faz o site virar "app" no celular
│   └── sw.js            ← Service Worker (funciona offline)
├── src/
│   ├── App.js           ← App principal
│   ├── lib/
│   │   ├── db.js        ← Banco de dados (local + Supabase)
│   │   └── supabase.js  ← Configuração do Supabase
│   ├── components/
│   │   └── ui.js        ← Componentes visuais
│   └── screens/
│       ├── HomeScreen.js
│       ├── AgendaScreen.js
│       ├── ApptDetail.js
│       ├── ClientesScreen.js
│       ├── FinanceiroScreen.js
│       └── ConfigScreen.js
└── package.json
```

---

## PASSO 1 — Rodar localmente (testar no seu computador)

```bash
# Instalar Node.js em: https://nodejs.org (versão LTS)

# Abra o terminal na pasta do projeto
cd fisiopilates

# Instalar dependências
npm install

# Rodar o app localmente
npm start
# Abre em: http://localhost:3000
```

---

## PASSO 2 — Publicar como site/PWA (GRATUITO — Vercel)

### 2.1 Criar conta no GitHub
1. Acesse https://github.com e crie uma conta gratuita
2. Clique em "New repository" → nomeie "fisiopilates-app"
3. Marque "Public" e clique "Create repository"

### 2.2 Subir o código
```bash
cd fisiopilates
git init
git add .
git commit -m "FisioPilates app inicial"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/fisiopilates-app.git
git push -u origin main
```

### 2.3 Publicar no Vercel (gratuito)
1. Acesse https://vercel.com e clique "Sign up with GitHub"
2. Clique "New Project" → selecione "fisiopilates-app"
3. Clique "Deploy" — pronto!
4. Seu app estará em: **https://fisiopilates-app.vercel.app**

### 2.4 Domínio próprio (opcional, ~R$40/ano)
No painel do Vercel: Settings → Domains → adicione "fisiopilatescarinantunes.com.br"
- Registro de domínio: https://registro.br

---

## PASSO 3 — Banco de dados na nuvem (Supabase — GRATUITO)

Sem isso, os dados ficam só no celular/navegador de quem usa.
Com Supabase, ficam na nuvem e aparecem em qualquer dispositivo.

### 3.1 Criar projeto
1. Acesse https://supabase.com → "Start your project"
2. Crie uma organização → "New project"
3. Nome: "fisiopilates" | Senha: crie uma forte | Região: South America (São Paulo)

### 3.2 Criar as tabelas
1. No painel do Supabase: clique em "SQL Editor"
2. Cole e execute o SQL que está em `src/lib/supabase.js` (seção comentada)

### 3.3 Conectar ao app
1. No Supabase: Settings → API → copie "Project URL" e "anon public key"
2. No Vercel: Settings → Environment Variables → adicione:
   - `REACT_APP_SUPABASE_URL` = sua URL
   - `REACT_APP_SUPABASE_ANON_KEY` = sua chave
3. Redeploy no Vercel

---

## PASSO 4 — App Android (Google Play Store)

### 4.1 Usar PWABuilder (mais simples)
1. Acesse https://www.pwabuilder.com
2. Cole a URL do seu site (Vercel)
3. Clique "Package for stores" → Android
4. Baixe o arquivo `.apk` gerado

### 4.2 Publicar na Play Store
1. Crie conta de desenvolvedor: https://play.google.com/console
   - Taxa única: **R$130**
2. Crie novo app → suba o APK
3. Preencha ficha (nome, descrição, screenshots)
4. Envie para revisão (2-7 dias)

### 4.3 Método avançado (React Native / Expo)
Para melhor performance, reescreva em React Native:
```bash
npx create-expo-app fisiopilates-native
# O código é ~85% compatível com o React atual
```

---

## PASSO 5 — App iOS (App Store)

### 5.1 Requisitos
- **Obrigatório:** Mac com Xcode instalado (ou usar serviço como MacStadium)
- **Obrigatório:** Apple Developer Program: **U$99/ano (~R$500)**

### 5.2 Via PWABuilder
1. Em https://www.pwabuilder.com → iOS → baixe o pacote
2. Abra no Xcode → ajuste Bundle ID
3. Arquive e envie via Xcode para App Store Connect
4. Revisão: 1-3 dias

### 5.3 Alternativa mais barata para iOS
Disponibilize como PWA. No iPhone:
1. Abra Safari → acesse seu site
2. Compartilhar → "Adicionar à Tela de Início"
3. Vira um ícone igual a um app (sem precisar da App Store)

---

## PASSO 6 — Vender para outras clínicas (SaaS)

Para cobrar mensalidade de outras clínicas:

### Tecnologias necessárias
- **Auth:** Supabase Auth (login por clínica)
- **Pagamento:** Stripe (internacional) ou Mercado Pago (Brasil)
- **Multi-tenant:** Row Level Security no Supabase por `clinic_id`

### Sugestão de preço
| Plano | Preço/mês | Funcionalidades |
|-------|-----------|-----------------|
| Básico | R$49 | 1 profissional, até 50 clientes |
| Profissional | R$99 | 3 profissionais, ilimitado |
| Clínica | R$199 | Equipe completa + relatórios |

### Próximos passos para o SaaS
1. Adicionar tela de login/cadastro (Supabase Auth)
2. Isolar dados por clínica (clinic_id em todas as tabelas)
3. Integrar Mercado Pago para cobrança recorrente
4. Landing page apresentando o produto

---

## Resumo de custos

| Item | Custo | Quando |
|------|-------|--------|
| Site (Vercel) | **Gratuito** | Agora |
| Banco de dados (Supabase) | **Gratuito** | Agora |
| Domínio .com.br | ~R$40/ano | Opcional |
| Google Play | R$130 único | Quando quiser Android |
| Apple Developer | ~R$500/ano | Quando quiser iOS |
| **Total mínimo para começar** | **R$0** | Hoje |

---

## Contato para suporte técnico

Para qualquer dúvida sobre deploy, banco de dados ou publicação nas lojas,
volte aqui e pergunte — cada passo pode ser detalhado mais.
